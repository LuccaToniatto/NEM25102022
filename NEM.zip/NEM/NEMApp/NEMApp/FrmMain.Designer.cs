﻿namespace NEMApp
{
    partial class FrmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.msmManager = new MetroFramework.Components.MetroStyleManager(this.components);
            this.MenuVertical = new System.Windows.Forms.Panel();
            this.mtbLocalizarEntre = new MetroFramework.Controls.MetroButton();
            this.mcbDatas = new MetroFramework.Controls.MetroComboBox();
            this.mtbProcurar = new MetroFramework.Controls.MetroButton();
            this.mdtpDataSetting = new MetroFramework.Controls.MetroDateTime();
            this.pbxMenu = new System.Windows.Forms.PictureBox();
            this.mtpHoje = new MetroFramework.Controls.MetroDateTime();
            this.pbxLogo = new System.Windows.Forms.PictureBox();
            this.mtbRecarregar = new MetroFramework.Controls.MetroButton();
            this.mtbEscolher = new MetroFramework.Controls.MetroButton();
            this.lbldataatual = new System.Windows.Forms.Label();
            this.mtcbTemperaturas = new MetroFramework.Controls.MetroComboBox();
            this.lblAlarme = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMediaHora = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DGVNormal = new System.Windows.Forms.DataGridView();
            this.cbRisco = new System.Windows.Forms.CheckBox();
            this.DGVRisco = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.msmManager)).BeginInit();
            this.MenuVertical.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVNormal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVRisco)).BeginInit();
            this.SuspendLayout();
            // 
            // msmManager
            // 
            this.msmManager.Owner = null;
            this.msmManager.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // MenuVertical
            // 
            this.MenuVertical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(26)))), ((int)(((byte)(27)))));
            this.MenuVertical.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MenuVertical.Controls.Add(this.mtbLocalizarEntre);
            this.MenuVertical.Controls.Add(this.mcbDatas);
            this.MenuVertical.Controls.Add(this.mtbProcurar);
            this.MenuVertical.Controls.Add(this.mdtpDataSetting);
            this.MenuVertical.Controls.Add(this.pbxMenu);
            this.MenuVertical.Location = new System.Drawing.Point(-1, 12);
            this.MenuVertical.Name = "MenuVertical";
            this.MenuVertical.Size = new System.Drawing.Size(55, 432);
            this.MenuVertical.TabIndex = 0;
            // 
            // mtbLocalizarEntre
            // 
            this.mtbLocalizarEntre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.mtbLocalizarEntre.Location = new System.Drawing.Point(14, 132);
            this.mtbLocalizarEntre.Name = "mtbLocalizarEntre";
            this.mtbLocalizarEntre.Size = new System.Drawing.Size(200, 23);
            this.mtbLocalizarEntre.TabIndex = 8;
            this.mtbLocalizarEntre.Text = "Procurar entre estas datas";
            this.mtbLocalizarEntre.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.mtbLocalizarEntre.UseSelectable = true;
            // 
            // mcbDatas
            // 
            this.mcbDatas.FormattingEnabled = true;
            this.mcbDatas.ItemHeight = 23;
            this.mcbDatas.Items.AddRange(new object[] {
            "Hoje-Ontem",
            "Hoje-Três dias",
            "Hoje- Um mês",
            "Hoje- Três meses",
            "Hoje- Semestre Passado",
            "Hoje- Ano passado"});
            this.mcbDatas.Location = new System.Drawing.Point(14, 161);
            this.mcbDatas.Name = "mcbDatas";
            this.mcbDatas.Size = new System.Drawing.Size(200, 29);
            this.mcbDatas.TabIndex = 7;
            this.mcbDatas.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.mcbDatas.UseSelectable = true;
            // 
            // mtbProcurar
            // 
            this.mtbProcurar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.mtbProcurar.Location = new System.Drawing.Point(14, 221);
            this.mtbProcurar.Name = "mtbProcurar";
            this.mtbProcurar.Size = new System.Drawing.Size(200, 23);
            this.mtbProcurar.TabIndex = 4;
            this.mtbProcurar.Text = "Procurar por esta data";
            this.mtbProcurar.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.mtbProcurar.UseSelectable = true;
            // 
            // mdtpDataSetting
            // 
            this.mdtpDataSetting.Location = new System.Drawing.Point(14, 250);
            this.mdtpDataSetting.MinimumSize = new System.Drawing.Size(0, 29);
            this.mdtpDataSetting.Name = "mdtpDataSetting";
            this.mdtpDataSetting.Size = new System.Drawing.Size(200, 29);
            this.mdtpDataSetting.TabIndex = 4;
            this.mdtpDataSetting.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // pbxMenu
            // 
            this.pbxMenu.BackgroundImage = global::NEMApp.Properties.Resources.Menu;
            this.pbxMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxMenu.Location = new System.Drawing.Point(3, 3);
            this.pbxMenu.Name = "pbxMenu";
            this.pbxMenu.Size = new System.Drawing.Size(49, 49);
            this.pbxMenu.TabIndex = 0;
            this.pbxMenu.TabStop = false;
            this.pbxMenu.Click += new System.EventHandler(this.pbxMenu_Click);
            // 
            // mtpHoje
            // 
            this.mtpHoje.Enabled = false;
            this.mtpHoje.Location = new System.Drawing.Point(60, 35);
            this.mtpHoje.MinimumSize = new System.Drawing.Size(0, 29);
            this.mtpHoje.Name = "mtpHoje";
            this.mtpHoje.Size = new System.Drawing.Size(200, 29);
            this.mtpHoje.TabIndex = 19;
            this.mtpHoje.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // pbxLogo
            // 
            this.pbxLogo.BackgroundImage = global::NEMApp.Properties.Resources.hara;
            this.pbxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxLogo.Location = new System.Drawing.Point(60, 297);
            this.pbxLogo.Name = "pbxLogo";
            this.pbxLogo.Size = new System.Drawing.Size(170, 116);
            this.pbxLogo.TabIndex = 22;
            this.pbxLogo.TabStop = false;
            // 
            // mtbRecarregar
            // 
            this.mtbRecarregar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.mtbRecarregar.Location = new System.Drawing.Point(618, 242);
            this.mtbRecarregar.Name = "mtbRecarregar";
            this.mtbRecarregar.Size = new System.Drawing.Size(164, 23);
            this.mtbRecarregar.TabIndex = 21;
            this.mtbRecarregar.Text = "Recarregar Guia e Relatorio";
            this.mtbRecarregar.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.mtbRecarregar.UseSelectable = true;
            this.mtbRecarregar.Click += new System.EventHandler(this.mtbRecarregar_Click_1);
            // 
            // mtbEscolher
            // 
            this.mtbEscolher.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.mtbEscolher.Location = new System.Drawing.Point(661, 35);
            this.mtbEscolher.Name = "mtbEscolher";
            this.mtbEscolher.Size = new System.Drawing.Size(121, 23);
            this.mtbEscolher.TabIndex = 17;
            this.mtbEscolher.Text = "Set Relatorio";
            this.mtbEscolher.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.mtbEscolher.UseSelectable = true;
            this.mtbEscolher.Click += new System.EventHandler(this.mtbEscolher_Click_1);
            // 
            // lbldataatual
            // 
            this.lbldataatual.AutoSize = true;
            this.lbldataatual.ForeColor = System.Drawing.Color.White;
            this.lbldataatual.Location = new System.Drawing.Point(60, 15);
            this.lbldataatual.Name = "lbldataatual";
            this.lbldataatual.Size = new System.Drawing.Size(65, 15);
            this.lbldataatual.TabIndex = 20;
            this.lbldataatual.Text = "Data Atual:";
            // 
            // mtcbTemperaturas
            // 
            this.mtcbTemperaturas.FormattingEnabled = true;
            this.mtcbTemperaturas.ItemHeight = 23;
            this.mtcbTemperaturas.Items.AddRange(new object[] {
            "C°",
            "K°",
            "F°",
            "Todas"});
            this.mtcbTemperaturas.Location = new System.Drawing.Point(661, 64);
            this.mtcbTemperaturas.Name = "mtcbTemperaturas";
            this.mtcbTemperaturas.Size = new System.Drawing.Size(121, 29);
            this.mtcbTemperaturas.TabIndex = 18;
            this.mtcbTemperaturas.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.mtcbTemperaturas.UseSelectable = true;
            // 
            // lblAlarme
            // 
            this.lblAlarme.AutoSize = true;
            this.lblAlarme.ForeColor = System.Drawing.Color.White;
            this.lblAlarme.Location = new System.Drawing.Point(60, 78);
            this.lblAlarme.Name = "lblAlarme";
            this.lblAlarme.Size = new System.Drawing.Size(173, 15);
            this.lblAlarme.TabIndex = 23;
            this.lblAlarme.Text = "Total de alarmes deste relatorio:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(60, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 24;
            this.label1.Text = "------------";
            // 
            // lblMediaHora
            // 
            this.lblMediaHora.AutoSize = true;
            this.lblMediaHora.ForeColor = System.Drawing.Color.White;
            this.lblMediaHora.Location = new System.Drawing.Point(60, 126);
            this.lblMediaHora.Name = "lblMediaHora";
            this.lblMediaHora.Size = new System.Drawing.Size(109, 15);
            this.lblMediaHora.TabIndex = 25;
            this.lblMediaHora.Text = "Media alarmes p/h:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(60, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 26;
            this.label2.Text = "------------";
            // 
            // DGVNormal
            // 
            this.DGVNormal.AllowUserToAddRows = false;
            this.DGVNormal.AllowUserToDeleteRows = false;
            this.DGVNormal.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DGVNormal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVNormal.Location = new System.Drawing.Point(241, 271);
            this.DGVNormal.Name = "DGVNormal";
            this.DGVNormal.ReadOnly = true;
            this.DGVNormal.RowTemplate.Height = 25;
            this.DGVNormal.Size = new System.Drawing.Size(541, 150);
            this.DGVNormal.TabIndex = 27;
            // 
            // cbRisco
            // 
            this.cbRisco.AutoSize = true;
            this.cbRisco.ForeColor = System.Drawing.Color.White;
            this.cbRisco.Location = new System.Drawing.Point(618, 217);
            this.cbRisco.Name = "cbRisco";
            this.cbRisco.Size = new System.Drawing.Size(140, 19);
            this.cbRisco.TabIndex = 28;
            this.cbRisco.Text = "Listar somente alertas";
            this.cbRisco.UseVisualStyleBackColor = true;
            this.cbRisco.CheckedChanged += new System.EventHandler(this.cbRisco_CheckedChanged);
            // 
            // DGVRisco
            // 
            this.DGVRisco.AllowUserToAddRows = false;
            this.DGVRisco.AllowUserToDeleteRows = false;
            this.DGVRisco.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DGVRisco.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVRisco.Location = new System.Drawing.Point(241, 271);
            this.DGVRisco.Name = "DGVRisco";
            this.DGVRisco.ReadOnly = true;
            this.DGVRisco.RowTemplate.Height = 25;
            this.DGVRisco.Size = new System.Drawing.Size(541, 150);
            this.DGVRisco.TabIndex = 29;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.DGVRisco);
            this.Controls.Add(this.cbRisco);
            this.Controls.Add(this.DGVNormal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblMediaHora);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblAlarme);
            this.Controls.Add(this.mtpHoje);
            this.Controls.Add(this.pbxLogo);
            this.Controls.Add(this.mtbRecarregar);
            this.Controls.Add(this.mtbEscolher);
            this.Controls.Add(this.lbldataatual);
            this.Controls.Add(this.mtcbTemperaturas);
            this.Controls.Add(this.MenuVertical);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 450);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(800, 450);
            this.Name = "FrmMain";
            this.Resizable = false;
            this.ShowIcon = false;
            this.Style = MetroFramework.MetroColorStyle.Purple;
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.FrmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.msmManager)).EndInit();
            this.MenuVertical.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVNormal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVRisco)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Components.MetroStyleManager msmManager;
        private Panel MenuVertical;
        private PictureBox pbxMenu;
        private MetroFramework.Controls.MetroButton mtbProcurar;
        private MetroFramework.Controls.MetroComboBox mcbDatas;
        private MetroFramework.Controls.MetroDateTime mdtpDataSetting;
        private MetroFramework.Controls.MetroDateTime mtpHoje;
        private PictureBox pbxLogo;
        private MetroFramework.Controls.MetroButton mtbRecarregar;
        private MetroFramework.Controls.MetroButton mtbEscolher;
        private Label lbldataatual;
        private MetroFramework.Controls.MetroComboBox mtcbTemperaturas;
        private MetroFramework.Controls.MetroButton mtbLocalizarEntre;
        private Label lblAlarme;
        private Label label1;
        private Label lblMediaHora;
        private Label label2;
        private DataGridView DGVNormal;
        private CheckBox cbRisco;
        private DataGridView DGVRisco;
    }
}