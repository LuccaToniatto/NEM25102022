using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace NEMApp
{
    public partial class FrmMain : MetroFramework.Forms.MetroForm
    {


        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            MenuVertical.Width = 55;
            DGVRisco.Visible = false;
            this.StyleManager = msmManager;
            msmManager.Theme = MetroFramework.MetroThemeStyle.Dark;
            msmManager.Style = MetroFramework.MetroColorStyle.Purple;
            mtbProcurar.Visible = false;
            mtbLocalizarEntre.Visible = false;
            mcbDatas.Visible = false;
            mdtpDataSetting.Visible = false;
            RelatorioFull rela = new RelatorioFull();
            List<RelatorioFull> li = rela.listaRelatorioFull();
            DGVNormal.DataSource = li;
            

        }

        private void pbxMenu_Click(object sender, EventArgs e)
        {
            if (MenuVertical.Width == 231)
            {
                MenuVertical.Width = 55;
                mtpHoje.Location = new Point(60, 35);
                lbldataatual.Location = new Point(60, 15);
                pbxLogo.Visible = true;
                mtbProcurar.Visible = false;
                mtbLocalizarEntre.Visible = false;
                mcbDatas.Visible = false;
                mdtpDataSetting.Visible = false;

            }
            else
            {
                MenuVertical.Width = 231;
                pbxLogo.Visible = false;
                mtpHoje.Location = new Point(236, 35);
                lbldataatual.Location = new Point(236, 15);
                mtbProcurar.Visible = true;
                mtbLocalizarEntre.Visible = true;
                mcbDatas.Visible = true;
                mdtpDataSetting.Visible = true;
            }
        }

        private void cbxTemperatura_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void mtbEscolher_Click(object sender, EventArgs e)
        {

        }

        private void mtbRecarregar_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mtbEscolher_Click_1(object sender, EventArgs e)
        {
            if(mtcbTemperaturas.Text == "C�")
            {
                RelatorioC relatorioC = new RelatorioC();
                List<RelatorioC> rel = relatorioC.listaRelatorioC();
                DGVNormal.DataSource = rel;
            }
            if(mtcbTemperaturas.Text == "F�")
            {
                RelatorioF relatorioC = new RelatorioF();
                List<RelatorioF> rel = relatorioC.listaRelatorioF();
                DGVNormal.DataSource = rel;
            }
            if(mtcbTemperaturas.Text == "K�")
            {
                RelatorioK relatorioC = new RelatorioK();
                List<RelatorioK> rel = relatorioC.listaRelatorioK();
                DGVNormal.DataSource = rel;
            }
            if(mtcbTemperaturas.Text== "Todas")
            {
                RelatorioFull rela = new RelatorioFull();
                List<RelatorioFull> li = rela.listaRelatorioFull();
                DGVNormal.DataSource = li;
            }
            else if(mtcbTemperaturas.Text == "")
            {
                MessageBox.Show("Por favor selecione um tipo de relatorio para ser listado na combo box abaixo!");
            }

        }

        private void mtbRecarregar_Click_1(object sender, EventArgs e)
        {
            if(mtcbTemperaturas.Text == "C�")
            {
                RelatorioC relatorioC = new RelatorioC();
                List<RelatorioC> rel = relatorioC.listaRelatorioC();
                DGVNormal.DataSource = rel;
            }
            if (mtcbTemperaturas.Text == "F�")
            {
                RelatorioF relatorioC = new RelatorioF();
                List<RelatorioF> rel = relatorioC.listaRelatorioF();
                DGVNormal.DataSource = rel;
            }
            if (mtcbTemperaturas.Text == "K�")
            {
                RelatorioK relatorioC = new RelatorioK();
                List<RelatorioK> rel = relatorioC.listaRelatorioK();
                DGVNormal.DataSource = rel;
            }
            if (mtcbTemperaturas.Text == "Todas")
            {
                RelatorioFull rela = new RelatorioFull();
                List<RelatorioFull> li = rela.listaRelatorioFull();
                DGVNormal.DataSource = li;
            }
            else if (mtcbTemperaturas.Text == "")
            {
                RelatorioFull rela = new RelatorioFull();
                List<RelatorioFull> li = rela.listaRelatorioFull();
                DGVNormal.DataSource = li;
            }
        }

        private void cbRisco_CheckedChanged(object sender, EventArgs e)
        {
            if (cbRisco.Checked == true)
            {
                DGVNormal.Visible = false;
                DGVRisco.Visible = true;
            }
            else if (cbRisco.Checked == false)
            {
                DGVRisco.Visible = false;
                DGVNormal.Visible = true;
            }
        }
    }
}