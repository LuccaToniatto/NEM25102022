﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace NEMApp
{
    public class RelatorioF
    {
        public int Id { get; set; }
        public int Farenheit { get; set; }
        public int Pressao { get; set; }
        public DateTime Data { get; set; }

        public List<RelatorioF> listaRelatorioF()
        {
            SqlConnection con = ClassConexao.ObterConexao();
            List<RelatorioF> li = new List<RelatorioF>();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Relatorio";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                RelatorioF re = new RelatorioF();
                re.Id = (int)dr["Id"];
                re.Farenheit = (int)dr["temperaturaf"];
                re.Pressao = (int)dr["pressao"];
                re.Data = Convert.ToDateTime(dr["data"]);
                li.Add(re);
            }
            return li;
        }
    }

}
